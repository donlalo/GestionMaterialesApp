<?php $__env->startSection('title', 'categorias'); ?>

<?php $__env->startSection('content'); ?>

<h1>Categorias</h1>

<hr>
<!-- MODAL -->

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal">Crear Categoria</button>

<!-- Modal -->
<div id="myModal" class="modal modal-primary fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header modal-primary">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Nueva Categoria</h4>
      </div>
      <div class="modal-body">
          <!-- FORM-->
          <form action="<?php echo e(route('categoria.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label for="">Nombre</label>
              <input type="text" class="form-control" name="nombre">
            </div>
            <div class="form-group">
              <label for="pwd">Descripcion</label>
              <input type="text" class="form-control" name="descripcion">
            </div>
            <button type="submit" class="btn btn-primary">Ingresar</button>
          </form> 
          <!-- END FORM-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>

  </div>
</div>
        

<!-- END MODAL -->
<hr>

<table class="table table-bordered">
    <thead>
      <tr class="head-table">
        <th>Id</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th>Creado</th>
        <th>Actualizacion</th>
        <th>Accion</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="body-table">
          <td><?php echo e($d->id); ?></td>
          <td><?php echo e($d->nombre); ?></td>
          <td><?php echo e($d->descripcion); ?></td>
          <td><?php echo e(date('d-m-Y H:i:s', strtotime($d->created_at))); ?></td>
          <td><?php echo e(date('d-m-Y H:i:s', strtotime($d->updated_at))); ?></td>
          <td>
          <a href="<?php echo e(url('categoria/editar', ['id' => $d->id ])); ?>" class="btn btn-default button-editar" >Editar</a>
          <a href="<?php echo e(url('categoria/eliminar', ['id' => $d->id ])); ?>" class="btn btn-default button-eliminar" >Eliminar</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($data->render()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>