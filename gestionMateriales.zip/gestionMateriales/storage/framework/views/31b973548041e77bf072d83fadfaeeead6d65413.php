<?php $__env->startSection('title', 'editar categoria'); ?>

<?php $__env->startSection('content'); ?>

<h1>Editar Categoria</h1>
<hr>

<form action="<?php echo e(url('/categoria/actualizar', ['id' => $categoria->id] )); ?>" method="POST" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label class="control-label col-sm-2" for="">Id:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" value="<?php echo e($categoria->id); ?>" disabled>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Nombre:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="nombre" value="<?php echo e($categoria->nombre); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Descripcion:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="descripcion" value="<?php echo e($categoria->descripcion); ?>">
        </div>
    </div>
    <div class="form-group">
            <label class="control-label col-sm-2" for=""></label>
            <div class="col-xs-4">
                <input type="submit" class="btn btn-primary btn-md" value="Actualizar Datos">
                <a href="<?php echo e(route('categoria.index')); ?>" class="btn btn-default btn-md">Volver</a>
            </div>
    </div>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>