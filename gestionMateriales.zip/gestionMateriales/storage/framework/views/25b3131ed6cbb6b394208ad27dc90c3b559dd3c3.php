<?php $__env->startSection('title', 'editar articulo'); ?>

<?php $__env->startSection('content'); ?>
<?php echo e($articulo->categoria->nombre); ?>

<h1>Editar articulo</h1>
<hr>
<form action="<?php echo e(url('/articulo/actualizar', ['id' => $articulo->id])); ?>" method="POST" class="form-horizontal">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
            <label class="control-label col-sm-2" for="">Id:</label>
            <div class="col-xs-4">
                <input type="text" class="form-control" value="<?php echo e($articulo->id); ?>" disabled>
            </div>
        </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Codigo:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="codigo" value="<?php echo e($articulo->codigo); ?>" required>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Nombre:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="nombre" value="<?php echo e($articulo->nombre); ?>" required>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Descripcion:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="descripcion" value="<?php echo e($articulo->descripcion); ?>" required>
        </div>
    </div>
    <div class="form-group">
            <label class="control-label col-sm-2" for="">Marca:</label>
            <div class="col-xs-4">
                <input type="text" class="form-control" name="marca" value="<?php echo e($articulo->marca); ?>" required >
            </div>
        </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Cantidad:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="cantidad" value="<?php echo e($articulo->cantidad); ?>" required>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Categoria:</label>
        <div class="col-xs-4">
        <select name="categoria" id="" class="form-control">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($c->id == $articulo->categoria->id): ?>
                <option value="<?php echo e($c->id); ?>" selected><?php echo e($c->nombre); ?></option>
                <?php else: ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->nombre); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </div>
    </div>
    <div class="form-group">
            <label class="control-label col-sm-2" for=""></label>
            <div class="col-xs-4">
                <input type="submit" class="btn btn-primary btn-md" value="Actualizar Datos">
                <a href="<?php echo e(route('articulo.index')); ?>" class="btn btn-default btn-md">Volver</a>
            </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>