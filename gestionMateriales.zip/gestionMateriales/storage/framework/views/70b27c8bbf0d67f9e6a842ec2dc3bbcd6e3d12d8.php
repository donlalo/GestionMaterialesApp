<?php $__env->startSection('title', 'articulos'); ?>

<?php $__env->startSection('content'); ?>

<h1>Articulos</h1>

<hr>

<form action="<?php echo e(route('articulo.busqueda' )); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <div class="input-group input-group-sm mb-3">
    <input type="search" name="busqueda" class="form-control" placeholder="ingresar palabra clave..." aria-describedby="basic-addon2">
    <div class="input-group-append">
      <input class="btn btn-outline-secondary" type="submit" value="Buscar" >
    </div>
  </div>
</form>

<hr>
<?php if(empty($data)): ?>
  <p>No hay articulos para mostrar.</p>
<?php endif; ?>

<?php if(isset($data)): ?>

  <table class="table-sm table-bordered">
    <thead>
      <tr class="head-table">
        <th>Id</th>
        <th>Codigo</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th>Marca</th>
        <th>Cantidad</th>
        <th>En Stock</th>
        <th>Categoria</th>
        <th>Accion</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="body-table">
            <td><?php echo e($d->id); ?></td>
          <td><?php echo e($d->codigo); ?></td>
          <td><?php echo e($d->nombre); ?></td>
          <td><?php echo e($d->descripcion); ?></td>
          <td><?php echo e($d->marca); ?></td>
          <td><?php echo e($d->cantidad); ?></td>
          <td></td>
        <td><?php echo e($d->categoria->nombre); ?></td>
          <td>
              <a href="<?php echo e(url('articulo/editar', ['id' => $d->id ])); ?>" class="btn btn-default button-editar" >Editar</a>
              <a href="<?php echo e(url('articulo/eliminar', ['id' => $d->id ])); ?>" class="btn btn-default button-eliminar" >Eliminar</a>
               </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php echo e($data->links()); ?>

<?php endif; ?>

<!--  -->



<!-- <input data-toggle="toggle" data-on="Si" data-off="No" type="checkbox" data-onstyle="success"> -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>