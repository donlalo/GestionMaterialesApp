<?php

namespace Materiales\Http\Controllers;

use Materiales\Articulo;
use Materiales\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ArticulosController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Articulo::paginate(15);
    
        return view('articulo.index')->with(['data' => $data]);
    }

    public function busqueda(Request $request)
    {
        $data = Articulo::where('nombre', 'like', '%'. $request->busqueda. '%')->paginate(15);
        
                return view('articulo.index')->with(['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'codigo' => 'required',
            'nombre' => 'required',
            'marca' => 'required',
            'cantidad' => 'required',
            'categoria_id' => 'required',
            ]);

            $a = new Articulo();
            $a->codigo = $request['codigo'];
            $a->nombre = $request['nombre'];
            $a->descripcion = $request['descripcion'];
            $a->marca = $request['marca'];
            $a->cantidad = $request['cantidad'];
            $a->categoria_id = $request['categoria_id']; 

            $a->save();


        return redirect()->route('articulo.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \Materiales\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function show(Articulo $articulo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Materiales\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $articulo = Articulo::find($id);
        $categorias = Categoria::all();

        return view('articulo.editar')->with(['articulo' => $articulo, 'categorias' => $categorias]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Materiales\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $articulo = Articulo::find($id);

        $articulo->codigo = $request->codigo;
        $articulo->nombre = $request->nombre;
        $articulo->descripcion = $request->descripcion;
        $articulo->marca = $request->marca;
        $articulo->cantidad = $request->cantidad;
        $articulo->categoria_id = $request->categoria;

        $articulo->save();

        return redirect()->route('articulo.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Materiales\Articulo  $articulo
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        DB::table('articulos')->where('id', '=', $id)->delete();
        
        return redirect()->route('articulo.index');
    }
}
