<?php

namespace Materiales;

use Illuminate\Database\Eloquent\Model;

class Articulo extends Model
{
    //
    protected $fillable = [
        'codigo', 'nombre', 'descripcion', 'marca', 'cantidad', 'categoria_id'
    ];

    public function categoria(){
        return $this->belongsTo('Materiales\Categoria');
    }
}
