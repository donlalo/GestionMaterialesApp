
@extends('template.home')

@section('title', 'categorias')

@section('content')

<h1>Categorias</h1>

<hr>
<!-- MODAL -->

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModal">Crear Categoria</button>

<!-- Modal -->
<div id="myModal" class="modal modal-primary fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header modal-primary">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Nueva Categoria</h4>
      </div>
      <div class="modal-body">
          <!-- FORM-->
          <form action="{{ route('categoria.store') }}" method="POST">
            {{ csrf_field() }}
            <div class="form-group">
              <label for="">Nombre</label>
              <input type="text" class="form-control" name="nombre">
            </div>
            <div class="form-group">
              <label for="pwd">Descripcion</label>
              <input type="text" class="form-control" name="descripcion">
            </div>
            <button type="submit" class="btn btn-primary">Ingresar</button>
          </form> 
          <!-- END FORM-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
      </div>
    </div>

  </div>
</div>
        

<!-- END MODAL -->
<hr>

<table class="table table-bordered">
    <thead>
      <tr class="head-table">
        <th>Id</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th>Creado</th>
        <th>Actualizacion</th>
        <th>Accion</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($data as $d)
        <tr class="body-table">
          <td>{{$d->id}}</td>
          <td>{{$d->nombre}}</td>
          <td>{{$d->descripcion}}</td>
          <td>{{ date('d-m-Y H:i:s', strtotime($d->created_at)) }}</td>
          <td>{{ date('d-m-Y H:i:s', strtotime($d->updated_at)) }}</td>
          <td>
          <a href="{{ url('categoria/editar', ['id' => $d->id ]) }}" class="btn btn-default button-editar" >Editar</a>
          <a href="{{ url('categoria/eliminar', ['id' => $d->id ]) }}" class="btn btn-default button-eliminar" >Eliminar</a>
          </td>
        </tr>
      @endforeach
    </tbody>
  </table>
  {{ $data->render() }}

@endsection
