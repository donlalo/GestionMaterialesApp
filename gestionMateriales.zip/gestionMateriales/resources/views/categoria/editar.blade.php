
@extends('template.home')

@section('title', 'editar categoria')

@section('content')

<h1>Editar Categoria</h1>
<hr>

<form action="{{ url('/categoria/actualizar', ['id' => $categoria->id] ) }}" method="POST" class="form-horizontal">
    {{ csrf_field() }}
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Id:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" value="{{ $categoria->id}}" disabled>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Nombre:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="nombre" value="{{ $categoria->nombre}}">
        </div>
    </div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="">Descripcion:</label>
        <div class="col-xs-4">
            <input type="text" class="form-control" name="descripcion" value="{{ $categoria->descripcion }}">
        </div>
    </div>
    <div class="form-group">
            <label class="control-label col-sm-2" for=""></label>
            <div class="col-xs-4">
                <input type="submit" class="btn btn-primary btn-md" value="Actualizar Datos">
                <a href="{{ route('categoria.index') }}" class="btn btn-default btn-md">Volver</a>
            </div>
    </div>
</form>



@endsection