
@extends('template.home')

@section('title', 'articulos')

@section('content')

<h1>Articulos</h1>

<hr>

<div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="panel panel-default">
          <div class="panel-body">
            <!-- FORM-->
        <form action="{{ route('articulo.store') }}" method="POST">
            {{ csrf_field() }}
            <!-- -->
            <div class="form-group row">
              <div class="col-xs-6">
                <label for="">Codigo</label>
                <input type="text" class="form-control" name="codigo" required>
              </div>
              <div class="col-xs-6">
                <label for="">Nombre</label>
                <input type="text" class="form-control" name="nombre" required>
              </div>
              <div class="col-xs-12">
                <label for="pwd">Descripcion</label>
                <input type="text" class="form-control" name="descripcion" value="no aplica" required>
              </div>
              <div class="col-xs-6">
                <label for="">Marca</label>
                <input type="text" class="form-control" name="marca" required>
              </div>
              <div class="col-xs-6">
                <label for="">Cantidad</label>
                <input type="number" min="0" class="form-control" name="cantidad" required value="1">
              </div>
              <div class="col-xs-12">
                <label for="">Categoria</label>
              <select name="categoria_id" class="form-control" required>
                <!-- CARGAR CATEGORIAS-->
                @foreach($categorias as $c)
                  <option value="{{ $c->id}}">{{ $c->nombre }}</option>
                @endforeach
                <!-- FIN CATEGORIAS-->
              </select>
              </div>
            </div>
            <!-- -->
            <input type="submit" class="btn btn-primary" value="Ingresar">
            <button type="reset" class="btn btn-default">Limpiar</button>
  
          </form> 
          <!-- END FORM-->
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

  @endsection