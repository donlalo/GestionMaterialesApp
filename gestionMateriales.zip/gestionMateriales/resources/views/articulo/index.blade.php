
@extends('template.home')

@section('title', 'articulos')

@section('content')

<h1>Articulos</h1>

<hr>

<form action="{{ route('articulo.busqueda' ) }}" method="POST">
  {{ csrf_field() }}
  <div class="input-group input-group-sm mb-3">
    <input type="search" name="busqueda" class="form-control" placeholder="ingresar palabra clave..." aria-describedby="basic-addon2">
    <div class="input-group-append">
      <input class="btn btn-outline-secondary" type="submit" value="Buscar" >
    </div>
  </div>
</form>

<hr>
@empty($data)
  <p>No hay articulos para mostrar.</p>
@endempty

@isset($data)

  <table class="table-sm table-bordered">
    <thead>
      <tr class="head-table">
        <th>Id</th>
        <th>Codigo</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th>Marca</th>
        <th>Cantidad</th>
        <th>En Stock</th>
        <th>Categoria</th>
        <th>Accion</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($data as $d)
        <tr class="body-table">
            <td>{{$d->id}}</td>
          <td>{{$d->codigo}}</td>
          <td>{{$d->nombre}}</td>
          <td>{{$d->descripcion}}</td>
          <td>{{$d->marca}}</td>
          <td>{{$d->cantidad}}</td>
          <td></td>
        <td>{{$d->categoria->nombre}}</td>
          <td>
              <a href="{{ url('articulo/editar', ['id' => $d->id ]) }}" class="btn btn-default button-editar" >Editar</a>
              <a href="{{ url('articulo/eliminar', ['id' => $d->id ]) }}" class="btn btn-default button-eliminar" >Eliminar</a>
               </td>
        </tr>
      @endforeach
    </tbody>
  </table>
{{ $data->links() }}
@endisset

<!--  -->



<!-- <input data-toggle="toggle" data-on="Si" data-off="No" type="checkbox" data-onstyle="success"> -->



@endsection